const User = require('./user')
const Orders = require('./order')
const Rating = require('./rating')
const Store = require('./store')





module.exports={
    User,Orders,Rating,Store
}