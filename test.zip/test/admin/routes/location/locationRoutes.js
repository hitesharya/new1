// const express= require('express');
// const router = express.Router();
// const locCtrl = require('./locationController');

// router.get('/getstore',locCtrl.getStore);
// router.post('/putstore',locCtrl.putStore);

// module.exports = router;
