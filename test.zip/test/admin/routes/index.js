const express= require('express');
const router = express.Router();

 require('./auth/authRoutes')


 module.exports =router;
//require('./orders/orderRoutes')



